
package trabalho1;

import javax.swing.JOptionPane;


public class ContaEspecial extends Contas{
    
    private int limite;
    private int multa;
    private double aux;

    public int getMulta() {
        return multa;
    }

    public void setMulta(int multa) {
        this.multa = multa;
    }

    public int getLimite() {
        return limite;
    }

    public void setLimite(int limite) {
        this.limite = limite;
    }
    
    public void descontar(double multa){
        this.setSaldo(multa + this.aux);
    }
    
    public void sacar(double valor){
        if(valor <= this.getSaldo()){
            this.depositar(-valor);
            JOptionPane.showMessageDialog(null, "Saque efetuado com sucesso!");
            
        }else{ 
            if(valor <= this.getSaldo() + this.getLimite() && valor > this.getSaldo()){
                this.aux = this.getSaldo() - valor;
                descontar(this.getSaldo() - valor * this.multa / 100);
                JOptionPane.showMessageDialog(null, "Saque efetuado com sucesso (cheque especial)!");
            }
        }
    }
    
    public void tipoConta(){
        System.out.println("Tipo de conta: conta especial!");
    }
}
