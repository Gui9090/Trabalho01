
package trabalho1;

import javax.swing.JOptionPane;

public class Contas {
   private String nome;
   private int numero;
   private double saldo;

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
   
    public void tipoConta(){
        System.out.println("Tipo de conta: Comum");
    }
    
    public void sacar(double valor){
        if(valor <= saldo){
            double novoSaldo = saldo - valor;
            this.saldo = novoSaldo;
            JOptionPane.showMessageDialog(null, "Saque efetuado com sucesso!");
        }
        else JOptionPane.showMessageDialog(null, "Saldo insuficiente!");
    }
    
    public void depositar(double valor){
        this.saldo = saldo + valor;
    }

    public void transferir(Contas conta1, Contas conta2, double valor){
        if(valor > conta1.getSaldo()){
            JOptionPane.showMessageDialog(null, "Saldo insuficiente!");
          }else{
            conta1.saldo -= valor;
            conta2.saldo += valor;
            JOptionPane.showMessageDialog(null, "Transferência realizada com sucesso!");
        }
    }
}
