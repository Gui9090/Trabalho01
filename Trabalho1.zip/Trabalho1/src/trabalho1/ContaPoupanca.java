
package trabalho1;

import javax.swing.JOptionPane;


public class ContaPoupanca extends Contas{
   
    private double taxa;

    public double getTaxa() {
        return taxa;
    }

    public void setTaxa(double taxa) {
        this.taxa = taxa;
    } 
    
    public void reajustar(){
        double saldoAtual = this.getSaldo();
        double reajuste = saldoAtual * this.taxa;
        this.setSaldo(reajuste + this.getSaldo());
        JOptionPane.showMessageDialog(null, "Reajuste realizado com a taxa definida!");
    }
    
    public void reajusta(){
        double saldoAtual = this.getSaldo();
        double reajuste = saldoAtual * 0.1;
        this.depositar(reajuste);
        JOptionPane.showMessageDialog(null, "Reajuste realizado!");
    }
    
    public void tipoConta(){
        System.out.println("Tipo de conta: conta-poupança!");
    }
}
